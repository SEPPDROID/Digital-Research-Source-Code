FreeGEM video drivers: GSX version
==================================

  This zipfile contains the following FreeGEM video drivers, which I have 
been able to compile but not test. They may work; they may fail; they
may crash your system. If you have suitable hardware and are able to test 
any of them, let me know how you get on.

  In general these have not been patched for GSX compatibility and so will
probably display the wrong colours; there may be other problems as well.

Driver     | Resolution | Colours | Supported hardware
===========+============+=========+=========================================
SDDEB9.GSX | 640x400    | 16      | AT&T 6300 Display Enhancement Board
SDGEN9.GSX | 1008x728   |  2      | Genius card
SDP649.GSX | 640x480    | 16      | Quadram Prosync
SDP759.GSX | 752x358    | 16      | Quadram Prosync
SDWYS9.GSX | 1280x800   |  2      | Wyse 700 
===========+============+=========+=========================================
