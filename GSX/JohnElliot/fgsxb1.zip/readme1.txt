FreeGEM video drivers: GSX version
==================================

  This zipfile contains 24 GSX drivers based on the GEM/3 driver source tree.
They have all been tested to a greater or lesser extent.

  To install one of these drivers, rename it from .GSX to .SYS and 
put a reference to it in your ASSIGN.SYS file. Note that you will probably
have to reorder your ASSIGN.SYS file so that the video driver is mentioned
first (since these GEM-based drivers are considerably larger than the true
GSX drivers they replace).

The drivers are:

Name       | Resolution | Colours | Compatible hardware
===========+============+=========+=======================================
SD2569.GSX | 1024x768   | 256     | VESA capable of 1024x768
SDAMS9.GSX |  640x200   |  16     | Amstrad PC1512
SDATT9.GSX |  640x400   |   2     | AT&T 6300; Compaq Portable III; 
           |            |         | DEC VAXmate; Toshiba 3100e
SDCAT9.GSX |  640x400   |   2     | As SDATT9, but also supports standard
           |            |         | CGA (at 640x200 resolution)
SDCGA9.GSX |  640x200   |   2     | CGA
SDCLF9.GSX |  320x200   |   4     | CGA
SDCLR9.GSX |  320x200   |   4     | CGA, reverse video
SDEH19.GSX |  640x350   |   2     | EGA with EGA or MDA monitor
SDEH89.GSX |  640x350   |   8     | EGA with EGA monitor and > 64k
SDEHF9.GSX |  640x350   |  16     | EGA with EGA monitor and > 64k
SDEL89.GSX |  640x200   |   8     | EGA with EGA or CGA monitor
SDELF9.GSX |  640x200   |  16     | EGA with EGA or CGA monitor
SDHRC9.GSX |  720x348   |   2     | Hercules
SDKHM9.GSX |  720x350   |   2     | IBM 3270 PC
SDKLF9.GSX |  360x350   |   4     | IBM 3270 PC
SDPAR9.GSX |  640x480   | 256     | Paradise VGA
SDPLA9.GSX |  640x200   |   4     | Plantronics ColorPlus / ATI Small Wonder
SDPSC9.GSX |  640x480   |  16     | VGA
SDPSM9.GSX |  640x480   |   2     | VGA or MCGA
SDRCG9.GSX |  640x200   |   2     | CGA, reverse video (for LCD screens)
SDU869.GSX |  800x600   |  16     | Paradise; Trident; VESA-compatible cards
           |            |         | Use VIDPATCH to support other chipsets
SDUNI9.GSX |  640x480   |  16     | VGA, MCGA and EGA
SDVES9.GSX |  800x600   |  16     | VESA capable of 800x600
SDVLF9.GSX |  320x200   | 256     | VGA
===========+============+=========+=======================================

Other compatibility issues
==========================

  VIDPATCH.EXE has been supplied to force the use of a particular video mode
in the multiple-mode drivers in case the automatic video mode probes 
do not work as expected. The following commands override the probe:

VIDPATCH SDUNI9.GSX 0	  -- force EGA mono
VIDPATCH SDUNI9.GSX 1	  -- force EGA colour
VIDPATCH SDUNI9.GSX 2	  -- force VGA/MCGA mono
VIDPATCH SDUNI9.GSX 3 	  -- force VGA colour
VIDPATCH SDUNI9.GSX AUTO  -- go back to automatic probe

VIDPATCH SDCAT9.GSX 6	  -- force CGA mode
VIDPATCH SDCAT9.GSX 64	  -- force AT&T 6300 mode
VIDPATCH SDCAT9.GSX 116	  -- force Toshiba 3100e mode
VIDPATCH SDCAT9.GSX AUTO  -- go back to automatic probe

VIDPATCH SDPAR9.GSX 94    -- force 640x400 mode
VIDPATCH SDPAR9.GSX 95    -- force 640x480 mode
VIDPATCH SDPAR9.GSX AUTO  -- go back to automatic probe

VIDPATCH SDU869.GSX <mode>   Select an 800x600 mode, specified by a decimal
		             number. Consult the documentation for your 
			     video card to see which mode to choose - for 
                             example, Oak chipsets use mode 82.
VIDPATCH SDU869.GSX AUTO  -- go back to automatic probe, which should work on
			     Trident, Paradise and VESA-compatible chipsets
