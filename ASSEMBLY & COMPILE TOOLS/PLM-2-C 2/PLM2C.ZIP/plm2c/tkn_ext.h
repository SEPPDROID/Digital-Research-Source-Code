
/*
 *	Reserved word list
 */
extern	RESERVED_WORD reserved_words[];

/*
 *	Operator list
 */
extern	RESERVED_OPERATOR reserved_operators[];

/*
 *	Control directives list
 */
extern	RESERVED_WORD control_directives[];
