char	version[] = "Version 1.02 (Alpha)";
